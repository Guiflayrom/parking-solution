import numpy as np
import cv2
import imutils
import tensorflow as tf
from keras import models
import keras
import glob
from tensorflow.keras import layers


vazia_folder = glob.glob('vazia/*.jpg')
ocupada_folder = glob.glob('ocupada/*.jpg')

x = []
y = []

for i in vazia_folder:

	image = cv2.imread(i)
	print(i)

	x.append(image)
	y.append(0)
	
for i in ocupada_folder:
	image = cv2.imread(i)
	print(i)
	x.append(image)
	y.append(1)



X = np.array(x)
X = X / 255.  
y = np.array(y)


epochs = 20         
model = keras.Sequential(
    [
        keras.Input(shape=(100,100,3)),
        layers.Conv2D(32, kernel_size=(3, 3), activation="relu"),
        layers.MaxPooling2D(pool_size=(2, 2)),
        layers.Conv2D(64, kernel_size=(3, 3), activation="relu"),
        layers.MaxPooling2D(pool_size=(2, 2)),
        layers.Flatten(),
        layers.Dropout(0.5),
        layers.Dense(len(np.unique(y)), activation="softmax"),
    ]
)

model.fit(X, y, epochs=epochs)

model.save("classifica_vagas.h5")      

